//  scroll colorchange

window.addEventListener('scroll',()=>{
    document.querySelector('nav').classList.toggle
    ('window-scroll',window.scrollY>5)
})


    //    toggle navbar

$('#menu-btn').click(function(){
    $('nav .navigation ul').addClass('active') 
 });


$('#close-btn').click(function(){
   $('nav .navigation ul').removeClass('active') 
});

